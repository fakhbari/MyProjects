﻿$(function(){
    $(".FooterSlider").slick({
        rtl:true,
        infinite: true,
        slidesToShow: 4,
        arrows: false,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                infinite: true
            }
    
        }, {
    
            breakpoint: 575,
            settings: {
                slidesToShow: 1,
                dots: true
            }
    
        }]
    });
})